<tr>
        <td>
            <?php echo $x ?>
        </td>
        <td>
        <?php echo $y ?>
        </td>
        <td>
        <?php echo $r ?>
        </td>
        <td class="<?php echo $statusClass ?>">
        <?php echo $status ?>
        </td>
        <td>
        <?php echo $benchmark ?>
        </td>
        <td>
        <?php echo $time ?>
        </td>
</tr>