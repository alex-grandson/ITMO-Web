<?php
session_start();
echo 'Текущая версия PHP: ' . phpversion();
// $start = microtime(true);
// date_default_timezone_set("Europe/Moscow");

$x = json_decode($_GET['x']);
$y = intval($_GET['y']);
$r = intval($_GET['r']);


for($i = 0; $i < count($x); $i++){
    validation(intval($x[$i]),$y,$r, $start);
}



function validation($x,$y,$r, $start){
    print_r(2);
    if(squareCheck($x,$y,$r) OR TriangleCheck($x,$y,$r) OR RoundCheck($x,$y,$r)){
        $status = 'Попал';
        $statusClass = 'statusTrue';
        $time = date('h:i:s A');
        //$benchmark = number_format(microtime(true) - $start, 10, ".", "")*1000000;
        $benchmark = 'time';
        $data = array($x,$y,$r,$status,$statusClass,$time,$benchmark);
        $_SESSION['data'][] = $data;
        include('../views/row.php');
    }else{
        $status = 'Не попал';
        $statusClass = 'statusFalse';
        $time = date('h:i:s A');
        //$benchmark = number_format(microtime(true) - $start, 10, ".", "")*1000000;
        $benchmark = 'time';
        $data = array($x,$y,$r,$status,$statusClass,$time,$benchmark);
        $_SESSION['data'][] = $data;
        include('../views/row.php');
    }
}


function squareCheck($x,$y,$r){
    if((abs($x) <= $r) AND ($x <= 0) AND ($y <= 0) AND (abs($y) <= $r)){
        return true;
        
    }
}
function TriangleCheck($x,$y,$r){
    if((abs($x) <= $r) AND ($x >= 0) AND ($y >= 0) AND (abs($y) <= $r)){
        return true;
    }
}
function RoundCheck($x,$y,$r){
    if((abs($x) <= $r) AND ($x >= 0) AND ($y <= 0) AND (abs($y) <= $r)){
        return true;
    }
}
?>