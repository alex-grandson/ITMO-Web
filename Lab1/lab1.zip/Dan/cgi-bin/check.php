<?php
session_start();
$start = microtime(true);
date_default_timezone_set("Europe/Moscow");


$x = explode(',', $_GET['x']);
$y = floatval($_GET['y']);
$r = floatval($_GET['r']);

for($i = 0; $i < count($x); $i++){
    if($x[$i] > 3 || $x[$i] < -5 || $y < -3 || $y > 3 || $r < 1 || $r > 4){
        revalidate();
    }else{
        validation(intval($x[$i]),$y,$r, $start);
        
    }
    
}
function revalidate(){
    print_r('<tr><td>Проверьте правильность значений</td></tr>');
    die();
}
function validation($x,$y,$r, $start){
    
    if(squareCheck($x,$y,$r) OR TriangleCheck($x,$y,$r) OR RoundCheck($x,$y,$r)){
        $status = 'Попал';
        $statusClass = 'statusTrue';
        $time = date('h:i:s A');
        $benchmark = number_format(microtime(true) - $start, 10, ".", "")*1000 . 'ms';
        $data = array($x,$y,$r,$status,$statusClass,$time,$benchmark);
        $_SESSION['data'][] = $data;
        print_r('<tr><td>'.$x.'</td><td>'.$y.'</td><td>'.$r.'</td><td class="'.$statusClass.'">'.$status.'</td><td>'.$benchmark.'</td><td>'.$time.'</td></tr>');
    }else{
        $status = 'Не попал';
        $statusClass = 'statusFalse';
        $time = date('h:i:s A');
        $benchmark = number_format(microtime(true) - $start, 10, ".", "")*1000 . 'ms';
        $data = array($x,$y,$r,$status,$statusClass,$time,$benchmark);
        $_SESSION['data'][] = $data;
        print_r('<tr><td>'.$x.'</td><td>'.$y.'</td><td>'.$r.'</td><td class="'.$statusClass.'">'.$status.'</td><td>'.$benchmark.'</td><td>'.$time.'</td></tr>');
    }
}


function squareCheck($x,$y,$r){
    if($x <= 0 && $y >= -$r && $x >= -$r && $y <= 0){
        return true;
        
    }
}
function TriangleCheck($x,$y,$r){
    if($x >= 0 && $y >= 0 && $y <= -$x + $r){
        
        return true;
    }
}
function RoundCheck($x,$y,$r){
    if($x >= 0 && $y <= 0 && sqrt(pow($x,2)+pow($y,2)) <= $r){
        return true;
    }
}


?>