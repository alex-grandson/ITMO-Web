<!DOCTYPE html>
<html lang="ru">
  <head>
    <meta charset="utf-8">
    <title>Таблица</title>
    <!-- CSS -->
    <link rel="stylesheet" href="css/main.css">
    <!-- Favicon -->
    <link rel="icon" href="img/favicon/favicon.png" type="image/x-icon">
    <link rel="shortcut icon" href="img/favicon/favicon.png" type="image/x-icon">
  </head>
  <body>
    
  </body>
</html>
